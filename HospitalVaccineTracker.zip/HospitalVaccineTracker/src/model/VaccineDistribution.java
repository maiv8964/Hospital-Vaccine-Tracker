package model;

public class VaccineDistribution {

	private int nod;
	private Vaccine vaccine;
	
	public VaccineDistribution(Vaccine vaccine, int nod) {
		
		this.nod = nod;
		this.vaccine = vaccine;
		
	}
	
	public String toString() {
		
		String s = "";
		
		s += this.nod + " doses of " + vaccine.getcodeName() + " by " + vaccine.getManufacturer(); 
		
		return s;
	}
}
