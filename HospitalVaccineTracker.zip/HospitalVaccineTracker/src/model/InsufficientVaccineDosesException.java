package model;

public class InsufficientVaccineDosesException extends Exception {

	public InsufficientVaccineDosesException(String s) {
		
		super(s);
		
	}

}
