package model;

public class Vaccine {
	
	private String codeName;
	private String type;
	private String manufacturer;
	
	//verified vaccines in Canada
	private String[] vcodeName = {"mRNA-1273", "BNT162b2", "Ad26.COV2.S", "AZD1222"};
	private String[] vtype = {"RNA", "RNA", "Non Replicating Viral Vector", "Non Replicating Viral Vector"};
	private String[] vmanufacturer = {"Moderna", "Pfizer/BioNTech", "Janssen", "Oxford/AstraZeneca"};
	
	boolean verified;
	
	public Vaccine(String codeName, String type, String manufacturer) {
		
		this.codeName = codeName;
		this.type = type;
		this.manufacturer = manufacturer;
		this.verified = false;
		
		for(int i = 0; i < 4; i++) {
			
			if((this.codeName.equals(vcodeName[i])) && (this.type.equals(vtype[i])) && (this.manufacturer.equals(vmanufacturer[i]))) {
				
				this.verified = true;
				break;
				
			}
			
		}
				
	}
	
	public Vaccine() {
		
		this.manufacturer = "";
		this.codeName = "";
		
	}
	
	public boolean verifiedVaccine() {
		
		return this.verified;
		
	}
	
	public String getcodeName() {
		
		return this.codeName;
		
	}
	
	public String getType() {
		
		return this.type;
		
	}
	
	public String getManufacturer() {
		
		return this.manufacturer;		
		
	}
	
	public void setManufacturer(String manufacturer) {
		
		this.manufacturer = manufacturer;
		
	}
	
	
	
	public String toString() {
		
		String s = "";
		
		if(this.verified == true) {
			
			s += "Recognized vaccine: " + this.codeName + " (" + this.type + "; " + this.manufacturer + ")";
			
		}else {
			
			s += "Unrecognized vaccine: " + this.codeName + " (" + this.type + "; " + this.manufacturer + ")";
			
		}
		
		return s;
		
	}

}
