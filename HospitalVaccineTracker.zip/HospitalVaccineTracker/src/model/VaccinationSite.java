package model;

public class VaccinationSite {
	
	private int maxDoses;
	private int usedDoses;
	private String location;
	private String supplier;
	private int totalSupply;
	private int[] amount;
	private Vaccine[] vaccine;
	private int nov;
	private int index;
	private boolean vaccineAddedBefore;
	private String name;
	private HealthRecord hrName;
	private String date;
	private boolean administer;
	private int noa;
	private HealthRecord[] listApps;
	private int tempTotal;
	
	public VaccinationSite(String location, int maxDoses) {
		
		this.location = location;
		this.maxDoses = maxDoses;
		this.usedDoses = 0;
		this.totalSupply = 0;
		this.nov = 0;
		this.noa = 0;
		this.amount = new int[4];
		this.vaccine = new Vaccine [4];
		this.index = 0;
		this.vaccineAddedBefore = false;
		//this.maxapps = 200;
		this.listApps = new HealthRecord[200];
		this.name = "";
		this.date = "";
		this.administer = false;
		
		for(int i = 0; i < 4; i++) {
			
			this.vaccine[i] = new Vaccine();
			
		}		
		
	}

	public int getNumberOfAvailableDoses() {
		
		this.totalSupply = 0;
		
		for(int i = 0; i < 4; i++) {
			
			this.totalSupply += this.amount[i];
			
		}
		
		return this.totalSupply;
		
	}
	
	public int getNumberOfAvailableDoses(String supplier) {
		
		this.supplier = supplier;
		
		for(int i = 0; i < 4; i++) {
			
			if(vaccine[i].getcodeName().equals(this.supplier)) {
				
				return amount[i];
				
			}
			
		}
		
		return 0;

	}
	
	public void addDistribution(Vaccine vaccine, int amount) throws TooMuchDistributionException, UnrecognizedVaccineCodeNameException{

		
		this.nov++;
		this.tempTotal = 0;
		this.tempTotal += this.totalSupply;

		this.index = 0;
		this.vaccineAddedBefore = false;
		
		if(vaccine.verifiedVaccine() == false) {
			
			throw new UnrecognizedVaccineCodeNameException("Unexpected exception thrown");
			
		}else {
			
			for(int i = 0; i < 4; i++) {
				
				if(vaccine == this.vaccine[i]) { //check if vaccine name was already added previously
					
					this.vaccineAddedBefore = true;
					this.index = i;
					
				}
				
			}
			
			if(this.vaccineAddedBefore == true) {
				
				this.amount[this.index] += amount;
				this.nov--;
				
			}else {
				
				this.vaccine[this.nov - 1] = vaccine;
				this.amount[this.nov - 1] += amount;
				
			}
			
		}
		
		if((tempTotal += amount) > maxDoses) {
			
			throw new TooMuchDistributionException("Unexpected exception thrown");
		
		}else {
			
			this.totalSupply += amount;
			
		}
		
	}
	
	public void bookAppointment(HealthRecord name) throws InsufficientVaccineDosesException{

		this.hrName = name;
		this.listApps[this.noa] = name;
		
		int index = 0;
		boolean exists = false;
		
		for(int i = 0; i < 200; i++) {
			
			if(listApps[i] == name) {
				
				index = i;
				exists = true;
				break;
				
			}
			
		}
		
		
		if(this.usedDoses >= this.tempTotal) {
			
			this.listApps[index].setAppointmentLocation(this.location, false);
			throw new InsufficientVaccineDosesException("Unexpected exception thrown");
			
		}else {
			
			if(this.usedDoses > this.maxDoses) {
				
				throw new InsufficientVaccineDosesException("Unexpected exception thrown");
				
			}else {
				
				this.usedDoses++;
				this.noa++;
				this.listApps[index].setAppointmentLocation(this.location, true);	
				
			}
			
		}
		
	}
	
	public void administer(String date) throws InsufficientVaccineDosesException{
		
		this.date = date;
		this.administer = true;
		int nextAmount = 0;
		
		int tempnoa = this.noa;
		
		for(int j = 0; j < tempnoa; j++) {
			
			for(int i = 0; i < 4; i++) { // checks if there are no more vaccines in that type and goes to the next
				
				if(this.amount[i] == 0 && i != 3) {
					
					nextAmount = i + 1;
					
					if(this.amount[nextAmount] == 0) {
						
						nextAmount += 1;
						
						if(this.amount[nextAmount] == 0) {
							
							nextAmount += 1;
							
							if(this.amount[nextAmount] == 0) {
								
								//no more doses
								
							}
							
						}
						
					}
					
					break;
					
				}
				
				if(i == 3) {
					
					throw new InsufficientVaccineDosesException("Unexpected exception thrown");
					
				}
				
				if(nextAmount == i) {
					
					break;
					
				}
							
			}
			
			this.noa--;
			this.amount[nextAmount]--;
			this.totalSupply--;
			
			this.listApps[j].addRecord(this.vaccine[nextAmount], this.location, this.date);
			
		}
		
	}
		
	public String toString() {
		
		String s = "";

		if(this.tempTotal == 0) {
			
			s += this.location + " has " + this.totalSupply + " available doses: <";
		
		}else if(this.administer == true){
			
			s += this.location + " has " + this.totalSupply + " available doses: <";
			
			for(int i = 0; i < 4;) {
				
				if(!this.vaccine[i].getManufacturer().equals("")) {
					
					s += this.amount[i] + " doses of " + this.vaccine[i].getManufacturer() ;
					
				}
				
				i++;
				
				if(i < 3) {
					
					s += ", ";

				}
				
			}
			
		}else {
			
			s += this.location + " has " + this.totalSupply + " available doses: <";
					
			for(int i = 0; i < 4;) {
				
				if(this.amount[i] != 0) {
					
					s += this.amount[i] + " doses of " + this.vaccine[i].getManufacturer() ;
					
				}
				
				i++;
				
				if(i < 4 && this.amount[i] != 0) {
					
					s += ", ";

				}
				
			}
			
		}
		
		s += ">";
		return s;
		
	}

}
