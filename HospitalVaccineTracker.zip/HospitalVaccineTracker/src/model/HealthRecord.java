package model;

public class HealthRecord {
	
	private String name;
	private int doseLimit;
	private int nod;
	private Vaccine[] vaccine;
	private String[] hospital;
	private String[] date;
	private String location;
	private int tempnod;
	private boolean success;

	public HealthRecord(String name, int doseLimit) {
		
		this.name = name;
		this.doseLimit = doseLimit;
		this.vaccine = new Vaccine[5];
		this.hospital = new String[5];
		this.date = new String[5];
		this.location = "";
		this.tempnod = 0;
		this.success = false;
		
	}
	
	public HealthRecord() {
		
		this.name = "";
		
	}
	
	public String getVaccinationReceipt() {
		
		if(this.nod == 0) {
			
			return this.name + " has not yet received any doses.";
			
		}else {

			String s = "";
			
			s += "Number of doses " + this.name + " has received: " + this.nod + " [";
			
			for(int i = 0; i < nod;) {
				
				s += this.vaccine[i].toString() + " in " + this.hospital[i] + " on " + this.date[i];
				
				i++;
				
				if(i < nod) {
					
					s += "; ";

				}
				
			}
			
			return  s + "]";
			
		}
		
	}

	public String getAppointmentStatus() {
		
		if((this.nod == 0 && this.tempnod == 0) || (this.location.equals("") && this.success == false)) {
			
			return "No vaccination appointment for " + this.name + " yet";
			
		}else if(this.success == false && !this.location.equals("")){

			return "Last vaccination appointment for " + this.name + " with " + this.location + " failed";
			
		}else {
			
			return "Last vaccination appointment for " + this.name + " with " + this.location + " succeeded";
			
		}

	}
	
	public void setAppointmentLocation(String location, boolean success) {
		
		this.success = success;
		this.location = location;
		this.tempnod = 1;
		
	}

	public void addRecord(Vaccine vaccine, String hospital, String date) {
		
		this.nod++;
		this.vaccine[this.nod - 1] = vaccine;
		this.hospital[this.nod - 1] = hospital;
		this.date[this.nod - 1] = date;
		this.tempnod = 0;
		
	}
	
	
}
